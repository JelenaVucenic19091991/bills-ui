import { describe, it, expect } from 'vitest';
import { filterByBillType } from './billFilters';
import type { Bill } from '../types/bill';

const mockBills: Bill[] = [
  {
    uri: '/ie/oireachtas/bill/2026/53',
    number: '2026/53',
    billType: 'Public',
    status: 'Current',
    sponsor: 'Minister for Finance',
    titleEn: 'Finance Bill 2026',
    titleGa: 'An Bille Airgeadais, 2026',
  },
  {
    uri: '/ie/oireachtas/bill/2026/52',
    number: '2026/52',
    billType: 'Private',
    status: 'Withdrawn',
    sponsor: 'Paul Murphy',
    titleEn: 'Some Private Bill 2026',
    titleGa: 'An Bille Príobháideach, 2026',
  },
];

describe('filterByBillType', () => {
  it('returns all bills when type is all', () => {
    expect(filterByBillType(mockBills, 'all')).toHaveLength(2);
  });

  it('filters by type', () => {
    const result = filterByBillType(mockBills, 'Public');
    expect(result).toHaveLength(1);
    expect(result[0]?.billType).toBe('Public');
  });

  it('returns empty array when no bills match', () => {
    expect(filterByBillType(mockBills, 'Hybrid')).toHaveLength(0);
  });
});

